#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"

class CRobin;
class CTube;

class HelloWorld : public cocos2d::CCLayer
{
private:
	
	CRobin *_robin;
	float _middleY;
	cocos2d::CCArray* _clouds;
	cocos2d::CCArray* _tubes;
	
	cocos2d::CCLabelTTF *_scoreLabel;
	cocos2d::CCLabelTTF *_highScoreLabel;
	cocos2d::CCLabelTTF *_gameOverLabel;
	cocos2d::CCLabelTTF *_settingsLabel;
	cocos2d::CCLabelTTF *_restartLabel;
	cocos2d::CCLabelTTF *_exitLabel;
	
	float _nextSpawnTime;
	float _lastSpawnTime;
	bool _gameStarted;
	float _floorY;
	int _gameScore;
	
	
	void GameUpdate(float dt);
	void CreateClouds();
	void AddCloud(const float speed, const cocos2d::CCPoint position, const float scale, const int zIndex, const char *name, const float XOffset);
	void StopClouds();
	void StartClouds();
	void StopGame();
	void StartGame();
	void GameOver();
	void ExitApp();
	
	void SetSpawnTime();
	void SpawnNewTubes();
	void SpawnUpperOrLower(bool isUpper);
	void SpawnTubePair();
	void SpawnATube(bool isUpper, float yPos);
	CTube *GetNextTube();
	void UpdateScoreLabel();
	void UpdateGameOverLabel();
	void ReEnableAfterGameOver();
	
public:
    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();  

    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::CCScene* scene();
    
    // implement the "static node()" method manually
    CREATE_FUNC(HelloWorld);
	
	virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event);
	virtual void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event);
	virtual void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event);
};

#endif // __HELLOWORLD_SCENE_H__
