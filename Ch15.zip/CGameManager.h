//
//  CGameManager.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 10/03/14.
//
//

#ifndef __SimpleFloppyRobin__CGameManager__
#define __SimpleFloppyRobin__CGameManager__

#include "cocos2d.h"

class CGameManager {
	
public:
	
	static CGameManager *Instance();
	void RunScene(int Scene);

private:
	
	CGameManager(){};
	CGameManager(CGameManager const&){};
	CGameManager& operator=(CGameManager const&){};
	
	static CGameManager* _pInstance;
	
};

#endif /* defined(__SimpleFloppyRobin__CGameManager__) */
