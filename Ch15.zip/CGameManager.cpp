//
//  CGameManager.cpp
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 10/03/14.
//
//

#include "CGameManager.h"
#include "HelloWorldScene.h"
#include "CSplashScene.h"
#include "Constants.h"

USING_NS_CC;

CGameManager *CGameManager::_pInstance = NULL;


CGameManager *CGameManager::Instance() {
	if(!_pInstance) {
		_pInstance = new CGameManager;
	}
	
	return _pInstance;
}

void CGameManager::RunScene(int scene) {
	CCScene *pScene = NULL;
	
	if(scene == kSceneGame) {
		pScene = HelloWorld::scene();
	} else if(scene == kSceneSplash) {
		pScene = CSplashLayer::scene();
	}
	
	if(CCDirector::sharedDirector()->getRunningScene() == NULL) {
		CCDirector::sharedDirector()->runWithScene(pScene);
	} else {
		CCDirector::sharedDirector()->replaceScene(pScene);
	}
}










