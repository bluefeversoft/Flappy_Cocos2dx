//
//  CSettingsScene.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 11/03/14.
//
//

#ifndef __SimpleFloppyRobin__CSettingsScene__
#define __SimpleFloppyRobin__CSettingsScene__

#include <iostream>

#include "cocos2d.h"

class CSettingsLayer : public cocos2d::CCLayer
{
	
private:
	
	void AddLabelAtPosition(const cocos2d::CCPoint pos, cocos2d::CCLabelTTF *label, const int zIndex, const cocos2d::CCPoint anchor);
	void SetLabelValues();
	
	void IncEffects(const int inc);
	void IncMusic(const int inc);
	
	cocos2d::CCRect _effectPlusBox;
	cocos2d::CCRect _effectMinusBox;
	cocos2d::CCRect _musicPlusBox;
	cocos2d::CCRect _musicMinusBox;
	cocos2d::CCLabelTTF *_backButton;
	cocos2d::CCLabelTTF *_effectValue;
	cocos2d::CCLabelTTF *_musicValue;
	
public:
    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
	
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::CCScene* scene();
    
    // implement the "static node()" method manually
    CREATE_FUNC(CSettingsLayer);
	
	virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event);
	virtual void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event);
	virtual void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event);
	
};

#endif /* defined(__SimpleFloppyRobin__CSettingsScene__) */
