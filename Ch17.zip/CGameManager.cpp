//
//  CGameManager.cpp
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 10/03/14.
//
//

#include "CGameManager.h"
#include "HelloWorldScene.h"
#include "CSplashScene.h"
#include "Constants.h"
#include "SimpleAudioEngine.h"
#include "CSettingsScene.h"

#define kNumExplosions 2
#define kNumRobinTap 1
#define kNumSuccess 2

USING_NS_CC;

CGameManager *CGameManager::_pInstance = NULL;


CGameManager *CGameManager::Instance() {
	if(!_pInstance) {
		_pInstance = new CGameManager;
	}
	
	return _pInstance;
}

void CGameManager::RunScene(int scene) {
	CCScene *pScene = NULL;
	
	if(scene == kSceneGame) {
		pScene = HelloWorld::scene();
	} else if(scene == kSceneSplash) {
		pScene = CSplashLayer::scene();
	} else if(scene == kSceneSetttings) {
		pScene = CSettingsLayer::scene();
	}
	
	if(CCDirector::sharedDirector()->getRunningScene() == NULL) {
		CCDirector::sharedDirector()->runWithScene(pScene);
	} else {
		CCDirector::sharedDirector()->replaceScene(pScene);
	}
}

void CGameManager::PreLoadEffect(const char *name, int num) {
	char EffectName[32];
	memset(EffectName, 0, sizeof(EffectName));
	sprintf(EffectName, "%s%d.wav",name,num);
	CocosDenshion::SimpleAudioEngine::sharedEngine()->preloadEffect(EffectName);
}


void CGameManager::LateInit() {
	int i = 0;
	for (i = 0; i < kNumExplosions; ++i) {
		PreLoadEffect("Explosion", i + 1);
	}
	
	for (i = 0; i < kNumRobinTap; ++i) {
		PreLoadEffect("RobinTap", i + 1);
	}
	
	for (i = 0; i < kNumSuccess; ++i) {
		PreLoadEffect("Success", i + 1);
	}
	
	CocosDenshion::SimpleAudioEngine::sharedEngine()->preloadBackgroundMusic("BGMusic.mp3");
	
	SetEffectsVol(5);
	SetMusicVol(5);
}


void CGameManager::SetEffectsVol(const int Vol) {
	_effectsVol = Vol;
}

void CGameManager::SetMusicVol(const int Vol) {
	_musicVol = Vol;
	CocosDenshion::SimpleAudioEngine::sharedEngine()->setBackgroundMusicVolume((float)_musicVol / 10);
}


int CGameManager::GetEffectsVol() {
	return _effectsVol;
}

int CGameManager::GetMusicVol() {
	return _musicVol;
}


void CGameManager::PlayEffectName(const char *name, int NumSounds) {
	
	int nume = rand() % NumSounds + 1;
	
	char EffectName[32];
	memset(EffectName, 0, sizeof(EffectName));
	sprintf(EffectName, "%s%d.wav",name,nume);
	
	CocosDenshion::SimpleAudioEngine::sharedEngine()->setEffectsVolume((float)_effectsVol / 10);
	CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(EffectName);
}


void CGameManager::PlayEffect(const int EffectNum) {
	
	if(_effectsVol == 0) return;
	
	switch (EffectNum) {
		case kEffectRobinTap:
			PlayEffectName("RobinTap", kNumRobinTap);
			break;
			
		case kEffectExplosion:
			PlayEffectName("Explosion", kNumExplosions);
			break;
			
		case kEffectSuccess:
			PlayEffectName("Success", kNumSuccess);
			break;
			
		default:
			break;
	}
}

void CGameManager::StartBGMusic() {
	if(_musicVol == 0) return;
	CocosDenshion::SimpleAudioEngine::sharedEngine()->setBackgroundMusicVolume((float)_musicVol / 10);
	CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("BGMusic.mp3", true);
}

void CGameManager::StopBGMusic() {
	CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
}














