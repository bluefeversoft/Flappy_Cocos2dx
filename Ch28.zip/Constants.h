//
//  Constants.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 05/03/14.
//
//

#ifndef SimpleFloppyRobin_Constants_h
#define SimpleFloppyRobin_Constants_h

#define kZindexBackground 0
#define kZindexCloudSlow 10
#define kZindexCloudFast 20
#define kZindexMount 30
#define kZindexTube 35
#define kZindexFloor 40
#define kZindexTree 50
#define kZindexRobin 100

#define kRobinStateStopped 0
#define kRobinStateMoving 1
#define kRobinStartSpeedY 300 * GETSCALEY * GETSCALEFAC
#define kRobinStartX 240 * GETSCALEX * GETSCALEFAC

#define kCloudScaleSlow 0.4 * GETSCALEY
#define kCloudScaleFast 0.85 * GETSCALEY
#define kMountScale 0.8 * GETSCALEY
#define kTreeScale 1.0 * GETSCALEY


#define kCloudRestartX 100 * GETSCALEX * GETSCALEFAC
#define kMountRestartX 300 * GETSCALEX * GETSCALEFAC

#define kCloudSpeedSlow 13.0 * GETSCALEY * GETSCALEFAC
#define kCloudSpeedFast 53.0 * GETSCALEY * GETSCALEFAC
#define kMountSpeed 30.0 * GETSCALEY * GETSCALEFAC
#define kTreeSpeed 70.0 * GETSCALEY * GETSCALEFAC

#define kTubeStateInactive 0
#define kTubeStateActive 1

#define kTubeOffsetX 100 * GETSCALEX * GETSCALEFAC
#define kTubeInactiveX -1000 * GETSCALEX * GETSCALEFAC

#define kTubeSPawnMinTime 2.3
#define kTubeSpawnTimeVariance 8

#define kSingleGapTop 440 * GETSCALEY * GETSCALEFAC
#define kSingleGapBottom 230 * GETSCALEY * GETSCALEFAC
#define kSingleGapMax 280 * GETSCALEY * GETSCALEFAC
#define kSingleGapMin 160 * GETSCALEY * GETSCALEFAC

#define kDoubleGapTop 480 * GETSCALEY * GETSCALEFAC
#define kDoubleGapBottom 120 * GETSCALEY * GETSCALEFAC
#define kDoubleGapMax 220 * GETSCALEY * GETSCALEFAC
#define kDoubleGapMin 140 * GETSCALEY * GETSCALEFAC

#define GRAVITY -620 * GETSCALEY * GETSCALEFAC

#define kFontName "fonts/Marker Felt.ttf"
#define kTubeScore 1

#define kTubeTypeUpper 0
#define kTubeTypeLower 1
#define kTubeTypePair 2
#define kTubeTypeNone 3

#define kTubeMaxUpPixels 180 * GETSCALEY * GETSCALEFAC

#define kSceneSplash 0
#define kSceneGame 1
#define kSceneSetttings 2

#define kEffectRobinTap 0
#define kEffectSuccess 1
#define kEffectExplosion 2

#endif





















