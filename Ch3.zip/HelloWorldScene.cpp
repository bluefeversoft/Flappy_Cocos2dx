#include "HelloWorldScene.h"
#include "Constants.h"

USING_NS_CC;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

void HelloWorld::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	
}

void HelloWorld::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	
}

void HelloWorld::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	CCSetIterator i;
	CCTouch *touch;
	CCPoint tap;
	
	for (i = pTouches->begin(); i != pTouches->end(); i++) {
		touch = (CCTouch *)(*i);
		if(touch) {
			tap = touch->getLocation();
			CCLOG("Touched at %.2f,%.2f",tap.x,tap.y);
		}
	}
	
}


// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
    CCPoint origin = CCDirector::sharedDirector()->getVisibleOrigin();
	
	CCSprite *bgSprite = CCSprite::create("BG-HD.png");
	bgSprite->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	
	this->addChild(bgSprite, kZindexBackground);
	
	this->setTouchEnabled(true);
	
    return true;
}
