//
//  Constants.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 05/03/14.
//
//

#ifndef SimpleFloppyRobin_Constants_h
#define SimpleFloppyRobin_Constants_h

#define kZindexBackground 0

#endif
