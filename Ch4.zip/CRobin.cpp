//
//  CRobin.cpp
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 05/03/14.
//
//

#include "CRobin.h"

USING_NS_CC;

CRobin* CRobin::createRobinWithFileName(const char *fileName) {
	
	CRobin *sprite = new CRobin();
	if(sprite && sprite->initWithFile(fileName)) {
		sprite->autorelease();
		return sprite;
	}
	CC_SAFE_DELETE(sprite);
	return NULL;
}

void CRobin::UpdateRobin(float dt) {
	
}

void CRobin::Reset() {
	
}

int CRobin::GetState() {
	return 0;
}

void CRobin::SetState(int st) {
	
}

void CRobin::SetStartSpeed() {
	
}

