//
//  Constants.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 05/03/14.
//
//

#ifndef SimpleFloppyRobin_Constants_h
#define SimpleFloppyRobin_Constants_h

#define kZindexBackground 0
#define kZindexCloudSlow 10
#define kZindexCloudFast 20
#define kZindexMount 30
#define kZindexTube 35
#define kZindexFloor 40
#define kZindexTree 50
#define kZindexRobin 100

#define kRobinStateStopped 0
#define kRobinStateMoving 1
#define kRobinStartSpeedY 300 * GETSCALEY * GETSCALEFAC
#define kRobinStartX 240 * GETSCALEX * GETSCALEFAC

#define kCloudScaleSlow 0.4 * GETSCALEY
#define kCloudScaleFast 0.85 * GETSCALEY
#define kMountScale 0.8 * GETSCALEY
#define kTreeScale 1.0 * GETSCALEY


#define kCloudRestartX 100 * GETSCALEX * GETSCALEFAC
#define kMountRestartX 300 * GETSCALEX * GETSCALEFAC

#define kCloudSpeedSlow 28.0
#define kCloudSpeedFast 14.0
#define kMountSpeed 28.0
#define kTreeSpeed 9.0

#define kTubeStateInactive 0
#define kTubeStateActive 1

#define kTubeOffsetX 100 * GETSCALEX * GETSCALEFAC
#define kTubeInactiveX -1000 * GETSCALEX * GETSCALEFAC

#define kTubeSPawnMinTime 1.5
#define kTubeSpawnTimeVariance 20

#define kSingleGapTop 480 * GETSCALEY * GETSCALEFAC
#define kSingleGapBottom 160 * GETSCALEY * GETSCALEFAC
#define kSingleGapMax 320 * GETSCALEY * GETSCALEFAC
#define kSingleGapMin 160 * GETSCALEY * GETSCALEFAC

#define kDoubleGapTop 540 * GETSCALEY * GETSCALEFAC
#define kDoubleGapBottom 120 * GETSCALEY * GETSCALEFAC
#define kDoubleGapMax 280 * GETSCALEY * GETSCALEFAC
#define kDoubleGapMin 120 * GETSCALEY * GETSCALEFAC


#define GRAVITY -500 * GETSCALEY * GETSCALEFAC

#define kFontName "Marker Felt"
#define kTubeScore 1

#define kSceneSplash 0
#define kSceneGame 1
#define kSceneSetttings 2

#define kEffectRobinTap 0
#define kEffectSuccess 1
#define kEffectExplosion 2

#endif





















