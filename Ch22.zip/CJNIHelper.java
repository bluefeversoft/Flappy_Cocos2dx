// PUT YOUR PACKAGE NAME HERE
package com.xxxxx.xxxxx;

import android.util.Log;

public class CJNIHelper {
	private final static String TAG = "cocos2d-x debug info JAVA";
	
	public static void CallMyJavaSideJNI(int num) {
		Log.d(TAG,"CallMyJavaSideJNI() Called In Java With " + num);
	}
}
