//
//  CGameManager.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 10/03/14.
//
//

#ifndef __SimpleFloppyRobin__CGameManager__
#define __SimpleFloppyRobin__CGameManager__

#include "cocos2d.h"

class CGameManager {
	
public:
	
	static CGameManager *Instance();
	void RunScene(int Scene);
	
	void LateInit();
	
	void SetEffectsVol(const int Vol);
	void SetMusicVol(const int Vol);
	
	int GetEffectsVol();
	int GetMusicVol();
	
	void PlayEffect(const int EffectNum);
	
	void StartBGMusic();
	void StopBGMusic();
	
	float GetScaleX();
	float GetScaleY();
	float GetScaleFactor();
	
	void SetUpScaleFactors();
	
	void GetFileName(char *array, const int len, const char *name, const char *fileExt);
	void SaveSettingsToDisc();
	void LoadSettingsFromDisc();

private:
	
	CGameManager(){};
	CGameManager(CGameManager const&){};
	CGameManager& operator=(CGameManager const&){};
	
	static CGameManager* _pInstance;
	
	int _effectsVol;
	int _musicVol;
	
	float _scaleX;
	float _scaleY;
	float _scaleFactor;
	char *_extension;
	
	void PreLoadEffect(const char *name, int num);
	void PlayEffectName(const char *name, int NumSounds);
	
};

#define GETSCALEX ( CGameManager::Instance()->GetScaleX() )
#define GETSCALEY ( CGameManager::Instance()->GetScaleY() )
#define GETSCALEFAC ( CGameManager::Instance()->GetScaleFactor() )


#define SCALEX(p) ( (p) * GETSCALEX )
#define SCALEY(p) ( (p) * GETSCALEY )

#define SCALEPOS(x,y) ( ccp( GETSCALEX * (x) * GETSCALEFAC,  GETSCALEY * (y) * GETSCALEFAC) )

#define SCALEFONT(p) ((p) * GETSCALEY * GETSCALEFAC)

#define GETFILENAME(a,l,n,e) \
	(CGameManager::Instance()->GetFileName(a,l,n,e))

#define SCALENODE_XY(n) \
	n->setScaleX(GETSCALEX); \
	n->setScaleY(GETSCALEY)

#define SCALENODE_Y(n) \
	n->setScale(GETSCALEY)

#endif /* defined(__SimpleFloppyRobin__CGameManager__) */

















