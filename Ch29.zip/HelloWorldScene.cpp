#include "HelloWorldScene.h"
#include "CGameManager.h"
#include "Constants.h"
#include "CRobin.h"
#include "CCloud.h"
#include "CTube.h"
#include "MyJNIHelper.h"

USING_NS_CC;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

void HelloWorld::ExitApp() {
	CGameManager::Instance()->SaveSettingsToDisc();
	CCDirector::sharedDirector()->end();
}

void HelloWorld::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	CCSetIterator i;
	CCTouch *touch;
	CCPoint tap;
	
	for (i = pTouches->begin(); i != pTouches->end(); i++) {
		touch = (CCTouch *)(*i);
		if(touch) {
			tap = touch->getLocation();
			//CCLOG("Touched at %.2f,%.2f",tap.x,tap.y);
			if(_exitLabel->boundingBox().containsPoint(tap)) {
				CGameManager::Instance()->PlayEffect(kEffectRobinTap);
				CCLOG("Exit Pressed");
				this->setTouchEnabled(false);
				this->scheduleOnce(schedule_selector(HelloWorld::ExitApp), 0.5f);
			} else {
				if(_settingsLabel->boundingBox().containsPoint(tap) && _gameStarted == false) {
					CGameManager::Instance()->PlayEffect(kEffectRobinTap);
					CGameManager::Instance()->RunScene(kSceneSetttings);
				} else {
					CGameManager::Instance()->PlayEffect(kEffectRobinTap);
					if(_robin->GetState() == kRobinStateStopped) {
						StartGame();
					} else {
						_robin->SetStartSpeed();
					}
				}
			}
		}
	}
}

void HelloWorld::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	
}

void HelloWorld::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	
}

void HelloWorld::SetSpawnTime() {
	_lastSpawnTime = 0;
	_nextSpawnTime = (float)(rand() % kTubeSpawnTimeVariance) / 10 + kTubeSPawnMinTime;
}

void HelloWorld::SpawnNewTubes() {
	int ourChance = rand() % 3 + 1;
	
	while(1) {
		if(_lastTubeType == kTubeTypeUpper && ourChance == 1) {
			ourChance = rand() % 3 + 1;
		} else if(_lastTubeType == kTubeTypeLower && ourChance == 2) {
			ourChance = rand() % 3 + 1;
		} else if(_lastTubeType == kTubeTypePair && ourChance == 3) {
			ourChance = rand() % 3 + 1;
		} else {
			break;
		}
	}

	if(ourChance == 1) {
		SpawnUpperOrLower(true);
	} else if(ourChance == 2) {
		SpawnUpperOrLower(false);
	} else {
		SpawnTubePair();
	}
}

void HelloWorld::SpawnUpperOrLower(bool isUpper){
	_lastTubeType = isUpper == true ? kTubeTypeUpper : kTubeTypeLower;

	int Ymax = isUpper == true ? _middleY : kSingleGapTop;
	int Ymin = isUpper == true ? kSingleGapBottom : _middleY;

	if(isUpper == false) {
		if(Ymax - _lastGetUnderY > kTubeMaxUpPixels) {
			Ymax = _lastGetUnderY + kTubeMaxUpPixels;
		}
	}

	int YRange = abs(Ymax - Ymin);
	
	int Ypos = Ymax - rand() % YRange;
	
	if(isUpper) {
		_lastGetUnderY = Ypos;
	} else {
		_middleY = Ypos;
	}

	SpawnATube(isUpper, Ypos);
}

void HelloWorld::SpawnTubePair(){

	_lastTubeType = kTubeTypePair;

	int Gap = kDoubleGapMin + (rand() % (int)(kDoubleGapMax - kDoubleGapMin));
	int YRange = kDoubleGapTop - Gap - kDoubleGapBottom;
	int TopY = kDoubleGapTop - (rand() % YRange);
	int BottomY = TopY - Gap;

	_lastGetUnderY = TopY;

	SpawnATube(true, TopY);
	SpawnATube(false, BottomY);
}

void HelloWorld::SpawnATube(bool isUpper, float yPos){
	CTube *tube = GetNextTube();
	
	if(isUpper == true) {
		tube->setAnchorPoint(ccp(0.5,0));
		tube->setFlipY(false);
	} else {
		tube->setAnchorPoint(ccp(0.5,1));
		tube->setFlipY(true);
	}
	
	tube->setPositionY(yPos);
	tube->Start();
}

CTube *HelloWorld::GetNextTube() {
	CCObject *it;
	
	CCARRAY_FOREACH(_tubes, it) {
		CTube *tube = static_cast<CTube*>(it);
		if(tube->GetState() == kTubeStateInactive) {
			return tube;
		}
	}
	char FileName[32];
	GETFILENAME(FileName, 32, "Tube", ".png");
	CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
	CTube *newTube = CTube::createTubeWithFileName(FileName);
	SCALENODE_Y(newTube);
	newTube->Initialise(kTreeSpeed, visibleSize.width, kTubeOffsetX, kTubeInactiveX);
	this->addChild(newTube, kZindexTube);
	_tubes->addObject(newTube);
	return newTube;
}


void HelloWorld::GameUpdate(float dt) {
	
	if(_gameStarted == true) {
		
		_lastSpawnTime += dt;
		if(_lastSpawnTime > _nextSpawnTime) {
			SetSpawnTime();
			SpawnNewTubes();
		}
		
		bool gameOver = false;
		if(_robin->getPositionY() < _floorY) {
			gameOver = true;
		} else {
			CCObject *it;
			
			CCARRAY_FOREACH(_tubes, it) {
				CTube *tube = static_cast<CTube*>(it);
				if(tube->GetState() == kTubeStateActive) {
					if(_robin->TubeCollisionBox().intersectsRect(tube->boundingBox())) {
						gameOver = true;
					} else if(tube->GetIsScored() == false) {
						if(tube->boundingBox().origin.x + tube->boundingBox().size.width <
						   _robin->boundingBox().origin.x) {
							tube->SetIsScored();
							_gameScore += kTubeScore;
							CGameManager::Instance()->PlayEffect(kEffectSuccess);
						}
					}
				}
			}
		}
		
		UpdateScoreLabel();
		
		if(gameOver == true) {
			CGameManager::Instance()->PlayEffect(kEffectExplosion);
			UpdateGameOverLabel();
			GameOver();
		} else {
			_robin->UpdateRobin(dt);
		}
	}
	
}

void HelloWorld::UpdateScoreLabel() {
	char ScoreString[64];
	sprintf(ScoreString, "Score %d", _gameScore);
	_scoreLabel->setString(ScoreString);
}

void HelloWorld::UpdateGameOverLabel() {
	char GameOverString[64];
	sprintf(GameOverString, "GAME OVER! YOU SCORED %d !!", _gameScore);
	_gameOverLabel->setString(GameOverString);
}

void HelloWorld::CreateClouds() {
	_clouds = new CCArray();
	char FileName[32];
	GETFILENAME(FileName, 32, "Cloud", ".png");
	AddCloud(kCloudSpeedSlow, SCALEPOS(700,610), kCloudScaleSlow, kZindexCloudSlow, FileName, kCloudRestartX);
	AddCloud(kCloudSpeedSlow, SCALEPOS(150,570), kCloudScaleSlow, kZindexCloudSlow, FileName, kCloudRestartX);
	
	AddCloud(kCloudSpeedFast, SCALEPOS(150,300), kCloudScaleFast, kZindexCloudFast, FileName, kCloudRestartX);
	AddCloud(kCloudSpeedFast, SCALEPOS(400,500), kCloudScaleFast, kZindexCloudFast, FileName, kCloudRestartX);
	AddCloud(kCloudSpeedFast, SCALEPOS(880,400), kCloudScaleFast, kZindexCloudFast, FileName, kCloudRestartX);
	
	GETFILENAME(FileName, 32, "Mount", ".png");
	AddCloud(kMountSpeed, SCALEPOS(300,170), kMountScale, kZindexMount, FileName, kMountRestartX);
	AddCloud(kMountSpeed, SCALEPOS(800,170), kMountScale, kZindexMount, FileName, kMountRestartX);
	
	GETFILENAME(FileName, 32, "Tree", ".png");
	AddCloud(kTreeSpeed, SCALEPOS(128,72), kTreeScale, kZindexTree, FileName, kCloudRestartX);
	AddCloud(kTreeSpeed, SCALEPOS(624,72), kTreeScale, kZindexTree, FileName, kCloudRestartX);
	AddCloud(kTreeSpeed, SCALEPOS(864,72), kTreeScale, kZindexTree, FileName, kCloudRestartX);
	
}

void HelloWorld::AddCloud(const float speed, const cocos2d::CCPoint position, const float scale, const int zIndex, const char *name, const float XOffset) {
	CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
	CCloud *cloud = CCloud::createCloudWithFileName(name);
	cloud->SetSpeedAndWidth(speed, visibleSize.width, XOffset);
	cloud->setPosition(position);
	cloud->setScale(scale);
	this->addChild(cloud, zIndex);
	_clouds->addObject(cloud);
}

void HelloWorld::StopClouds() {
	CCObject *it;
	CCARRAY_FOREACH(_clouds, it) {
		CCloud *cloud = static_cast<CCloud*>(it);
		cloud->Stop();
	}
	
	CCARRAY_FOREACH(_tubes, it) {
		CTube *tube = static_cast<CTube*>(it);
		tube->stopAllActions();
	}
}

void HelloWorld::StartClouds() {
	CCObject *it;
	CCARRAY_FOREACH(_clouds, it) {
		CCloud *cloud = static_cast<CCloud*>(it);
		cloud->Start();
	}
	
	CCARRAY_FOREACH(_tubes, it) {
		CTube *tube = static_cast<CTube*>(it);
		tube->Stop();
	}
}

void HelloWorld::StopGame() {
	StopClouds();
	_gameStarted = false;
	_nextSpawnTime = 0.2;
}

void HelloWorld::StartGame() {
	CallMyJavaToastJNI(40, true);
	_restartLabel->setVisible(false);
	_robin->SetState(kRobinStateMoving);
	StartClouds();
	_gameStarted = true;
	_gameScore = 0;
	_lastTubeType = kTubeTypeNone;
	_lastGetUnderY = _middleY;
}

void HelloWorld::GameOver() {
	this->setTouchEnabled(false);
	_robin->Reset();
	StopGame();
	_gameOverLabel->setVisible(true);
	this->scheduleOnce(schedule_selector(HelloWorld::ReEnableAfterGameOver), 2.5f);
}

void HelloWorld::ReEnableAfterGameOver() {
	this->setTouchEnabled(true);
	_gameOverLabel->setVisible(false);
	_restartLabel->setVisible(true);
	_robin->setPositionY(_middleY);
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }

    CallMyJavaSideJNI(10);
	
	srand(time(NULL));
	
	const float ScoreFontSize = SCALEFONT(48);
	const float GameOverFontSize = SCALEFONT(48);
	const float ScorePositionX = 24 * GETSCALEX * GETSCALEFAC;
	const float ScorePositionY = 12 * GETSCALEY * GETSCALEFAC;
	const float SettingsGap = 24 * GETSCALEY * GETSCALEFAC;
    char FileName[32];
	
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();

	_middleY = visibleSize.height / 2;
	
	GETFILENAME(FileName, 32, "BG", ".png");
	CCSprite *bgSprite = CCSprite::create(FileName);
	SCALENODE_XY(bgSprite);
	bgSprite->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(bgSprite, kZindexBackground);
	
	GETFILENAME(FileName, 32, "Floor", ".png");
	CCSprite *floorSprite = CCSprite::create(FileName);
	SCALENODE_XY(floorSprite);
	floorSprite->setAnchorPoint(ccp(0,0));
	floorSprite->setPosition(ccp(0,0));
	this->addChild(floorSprite, kZindexFloor);
	_floorY = floorSprite->boundingBox().size.height / 2;
	
	GETFILENAME(FileName, 32, "Robin", ".png");
	_robin = CRobin::createRobinWithFileName(FileName);
	SCALENODE_Y(_robin);
	_robin->setPosition(ccp(kRobinStartX, visibleSize.height / 2));
	_robin->SetParams(visibleSize.height);
	this->addChild(_robin, kZindexRobin);
	
	_scoreLabel = CCLabelTTF::create("Score 0", kFontName, ScoreFontSize);
	_scoreLabel->setAnchorPoint(ccp(0,1));
	_scoreLabel->setPosition(ccp(ScorePositionX, visibleSize.height - ScorePositionY));
	_scoreLabel->setColor(ccRED);
	this->addChild(_scoreLabel, kZindexRobin);
	
	_highScoreLabel = CCLabelTTF::create("Best 0", kFontName, ScoreFontSize);
	_highScoreLabel->setAnchorPoint(ccp(0,1));
	_highScoreLabel->setPosition(ccp(ScorePositionX, _scoreLabel->boundingBox().origin.y - ScorePositionY));
	_highScoreLabel->setColor(ccRED);
	this->addChild(_highScoreLabel, kZindexRobin);
	
	_gameOverLabel = CCLabelTTF::create("Game Over", kFontName, GameOverFontSize);
	_gameOverLabel->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	_gameOverLabel->setColor(ccRED);
	_gameOverLabel->setVisible(false);
	this->addChild(_gameOverLabel, kZindexRobin);
	
	_restartLabel = CCLabelTTF::create("Tap The Robin To Restart", kFontName, GameOverFontSize);
	_restartLabel->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	_restartLabel->setColor(ccRED);
	_restartLabel->setVisible(true);
	this->addChild(_restartLabel, kZindexRobin);

	_settingsLabel = CCLabelTTF::create("SETTINGS", kFontName, GameOverFontSize);
	_settingsLabel->setPosition(ccp(visibleSize.width - SettingsGap, visibleSize.height  - SettingsGap));
	_settingsLabel->setColor(ccRED);
	_settingsLabel->setAnchorPoint(ccp(1,1));
	this->addChild(_settingsLabel, kZindexRobin);
	
	_exitLabel = CCLabelTTF::create("EXIT", kFontName, GameOverFontSize);
	_exitLabel->setPosition(ccp(visibleSize.width - SettingsGap, SettingsGap));
	_exitLabel->setColor(ccRED);
	_exitLabel->setAnchorPoint(ccp(1,0));
	this->addChild(_exitLabel, kZindexRobin);

	CreateClouds();
	_tubes = new CCArray();
	StopGame();
	
	CGameManager::Instance()->StartBGMusic();
	
	this->setTouchEnabled(true);
	this->schedule(schedule_selector(HelloWorld::GameUpdate));
	
    return true;
}
