#include "HelloWorldScene.h"
#include "Constants.h"

USING_NS_CC;

void HelloWorld::GameUpdate (float dt) {
	
	if(_ball->getPositionY() < 0) {
		CCLOG("Ball Off Screen");
		_ball->setPositionY(this->_middleY);
		_ball->Reset();
	} else {
		_ball->Update(dt);
	}
}

void HelloWorld::ccTouchesBegan(CCSet* pTouches, CCEvent* event) {
}

void HelloWorld::ccTouchesEnded(CCSet* pTouches, CCEvent* event) {
	CCSetIterator i;
	CCTouch* touch;
    CCPoint tap;
    
	//loop through all beginning touches
    for( i = pTouches->begin(); i != pTouches->end(); i++) {
		touch = (CCTouch*) (*i);
		
        if(touch) {
            //get location in OpenGL view
    		tap = touch->getLocation();
			if( _ball->boundingBox().containsPoint(tap)) {
				CCLOG("Ball Touched");
				if(_ball->GetState() == kBallStateStopped) {
					CCLOG("State Stoped, Changing");
					_ball->SetState(kBallStateMoving);
				} else {
					_ball->SetStartSpeed();
				}
			}
		}
	}
}

void HelloWorld::ccTouchesMoved(CCSet* pTouches, CCEvent* event) {
}

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
    CCPoint origin = CCDirector::sharedDirector()->getVisibleOrigin();

    CCSprite *bgSprite = CCSprite::create("BGHD.png");
	bgSprite->setPosition(ccp(visibleSize.width / 2,visibleSize.height/2 ));
	this->addChild(bgSprite);
	
	_ball = CBall::createBallWithFile("ball.png");
	_ball->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	_middleY = visibleSize.height / 2;
	this->addChild(_ball);
	
	this->setTouchEnabled(true);
	this->schedule(schedule_selector(HelloWorld::GameUpdate));
    
    return true;
}
