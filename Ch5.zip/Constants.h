//
//  Header.h
//  BouncyBall
//
//  Created by ScreenCast on 05/03/14.
//
//

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#define kBallStateMoving 1
#define kBallStateStopped 2

#define GRAVITY -500.00

#endif
