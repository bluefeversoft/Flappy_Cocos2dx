//
//  CBall.cpp
//  BouncyBall
//
//  Created by ScreenCast on 05/03/14.
//
//

#include "CBall.h"
#include "Constants.h"

USING_NS_CC;

CBall* CBall::createBallWithFile(const char * FileName) {
    CCLOG("Creating ball with name:%s",FileName);
    CBall * sprite = new CBall();
	if (sprite && sprite->initWithFile(FileName)) {
		sprite->Reset();
		sprite->autorelease();
		return sprite;
	}
	CC_SAFE_DELETE(sprite);
	return NULL;
}

void CBall::Reset() {
	CCLOG("Ball Reset");
	this->_state = kBallStateStopped;
	SetStartSpeed();
	InUD = false;
}

int CBall::GetState() {
	return this->_state;
}

void CBall::SetState(int state) {
	this->_state = state;
	CCLOG("Ball State Altered to :%d",this->_state);
}

void CBall::SetStartSpeed() {
	this->_speedY = StartSpeedY;
}

// s = ut + 0.5 * a * t * t

void CBall::Update(float dt) {
	
	if(InUD == true) {
		CCLOG("Update clash");
		return;
	}
	
	InUD = true;
	
	if(this->_state == kBallStateMoving) {
		float distance = 0;
		float newSpeed = 0;
		float OldSpeed = _speedY;
		distance = _speedY * dt + 0.5 * GRAVITY * dt * dt;
		newSpeed = _speedY + GRAVITY * dt;
		
		this->setPositionY(this->getPositionY() + distance);
		_speedY = newSpeed;
		
		CCLOG("Update dt:%.3f distance:%.2f OldSpeed:%.2f newSpeed:%.2f new posY:%.0f",dt,distance,OldSpeed,newSpeed,this->getPositionY());
	}
	
	InUD = false;
}


