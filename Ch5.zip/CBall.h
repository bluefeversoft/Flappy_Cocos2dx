//
//  CBall.h
//  BouncyBall
//
//  Created by ScreenCast on 05/03/14.
//
//

#ifndef __BouncyBall__CBall__
#define __BouncyBall__CBall__

#include <iostream>
#include "cocos2d.h"

class CBall : public cocos2d::CCSprite {
	
public:
	
	static CBall* createBallWithFile(const char * FileName);
	void Update(float dt);
	void Reset();
	int GetState();
	void SetState(int State);
	void SetStartSpeed();
	
	bool InUD;
	
private:
	
	const float StartSpeedY = 300;
	int _state;
	float _speedY;
	float lastUpdate;
	
};

#endif /* defined(__BouncyBall__CBall__) */
