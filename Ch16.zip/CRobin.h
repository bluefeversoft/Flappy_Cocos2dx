//
//  CRobin.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 05/03/14.
//
//

#ifndef __SimpleFloppyRobin__CRobin__
#define __SimpleFloppyRobin__CRobin__

#include "cocos2d.h"

class CRobin : public cocos2d::CCSprite {
	
public:

	static CRobin* createRobinWithFileName(const char *fileName);
	void UpdateRobin(float dt);
	void Reset();
	int GetState();
	void SetState(int st);
	void SetStartSpeed();
	cocos2d::CCRect TubeCollisionBox();
private:

	int _state;
	float _speedY;
};

#endif /* defined(__SimpleFloppyRobin__CRobin__) */
