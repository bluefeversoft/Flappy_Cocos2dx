//
//  CCloud.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 06/03/14.
//
//

#ifndef __SimpleFloppyRobin__CCloud__
#define __SimpleFloppyRobin__CCloud__

#include "cocos2d.h"

class CCloud : public cocos2d::CCSprite {
	
public:
	
	static CCloud* createCloudWithFileName(const char *fileName);
	void Start();
	void Stop();
	void SetSpeedAndWidth(const float speed, const float width, const float XOffset);
	
private:
	
	void ReachedDestination();
	
	float _speed;
	float _screenWidth;
	float _pixelsPerSec;
	float _xOffset;
	
};

#endif /* defined(__SimpleFloppyRobin__CCloud__) */
