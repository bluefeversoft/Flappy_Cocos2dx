//
//  CTube.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 07/03/14.
//
//

#ifndef __SimpleFloppyRobin__CTube__
#define __SimpleFloppyRobin__CTube__

#include "cocos2d.h"

class CTube : public cocos2d::CCSprite {
	
public:
	
	static CTube* createTubeWithFileName(const char *fileName);
	void Start();
	void Stop();
	void Initialise(const float speed, const float width,
					const float XOffset, const float InactiveX);
	int GetState();
	void SetIsScored();
	bool GetIsScored();
	
private:
	
	void ReachedDestination();
	int _state;
	float _speed;
	float _screenWidth;
	float _pixelsPerSec;
	float _xOffset;
	float _InactiveX;
	bool _scored;
};

#endif /* defined(__SimpleFloppyRobin__CTube__) */
